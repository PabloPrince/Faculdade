package com.model;

public enum Role {
	ADMIN, USER;
}

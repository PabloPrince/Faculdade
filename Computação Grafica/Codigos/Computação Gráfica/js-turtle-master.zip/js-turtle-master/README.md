Turtle graphics for Javascript, forked from bjpop/js-turtle.

Main enhancements I added are:

* reset button
* better error handling - alert instead of silent failure

You can access this live at

https://rawgit.com/wrschneider99/js-turtle/master/turtle.html

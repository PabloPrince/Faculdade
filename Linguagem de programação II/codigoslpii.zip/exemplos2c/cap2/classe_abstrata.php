<?php
include_once 'classes/Conta3.class.php';
$conta = new Conta;
?>

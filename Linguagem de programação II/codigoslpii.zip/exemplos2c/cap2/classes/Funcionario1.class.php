<?php
class Funcionario
{
    private $Codigo;
    public $Nome;
    private $Nascimento;
    private $Salario;
}
?>
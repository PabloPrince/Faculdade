Esta aplica��o est� licenciada sob a GPL
Para maiores informa��es, www.fsf.org
Contate o autor atrav�s do e-mail autor@aplicacao.com.br

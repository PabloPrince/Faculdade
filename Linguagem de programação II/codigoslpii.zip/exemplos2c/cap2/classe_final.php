<?php
include_once 'classes/Conta3.class.php';
include_once 'classes/ContaPoupanca.class.php';

class ContaPoupancaUniversitaria extends ContaPoupanca
{
    // ... sobrescrita de m�todos
}
?>

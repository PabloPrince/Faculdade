<?php
// cria objeto william
$william = new StdClass;
$william->nome = 'William Scatola';
$william->idade = 22;
$william->profissao = 'Controle de Estoque';

// cria objeto daline
$daline = new StdClass;
$daline->nome = 'Daline DallOglio';
$daline->idade = 21;
$daline->profissao = 'Almoxarifado';

print_r($william);
print_r($daline);
?>
<?php
/*
   * classe Fabricante
   * Active Record para tabela Fabricante
   */
class Fabricante extends TRecord
{
     const TABLENAME = 'fabricante';
	
}
?>


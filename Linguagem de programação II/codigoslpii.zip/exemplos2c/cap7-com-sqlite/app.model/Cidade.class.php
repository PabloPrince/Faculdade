<?php
/*
   * classe Cidade
   * Active Record para tabela Cidade
   */
class Cidade extends TRecord
{
     const TABLENAME = 'cidade';
	
}
?>


<?php
function __autoload($classe)
{
    if (file_exists("app.widgets/{$classe}.class.php"))
    {
        include_once "app.widgets/{$classe}.class.php";
    }
}

// exibe uma mensagem de informa��o
new TMessage('info', 'Esta a��o � inofensiva, isto � s� um lembrete');
?>
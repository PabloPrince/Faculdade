<?php

/**
 * @author Hudson Costa
 * @copyright 2015
 */

/*
 * fun��o __autoload()
 * carrega uma classe quando ela � necess�ria,
 * ou seja, quando ela � instancia pela primeira vez.
 */
 if (isSet($_POST['flag']))
{
function __autoload($classe)
{
    if (file_exists("app.ado/{$classe}.class.php"))
    {
        include_once "app.ado/{$classe}.class.php";
    }
}

try
{
  
    TTransaction::open('exemploBD');
  
    // cria uma instru��o de SELECT
    $sql = new TSqlSelect;
    
    // define o nome da entidade
    $sql->setEntity('clientes');
    
    // seleciona das colunas que v�o aparecer na consulta
    $sql->addColumn('nome');
    $sql->addColumn('endereco');
    $sql->addColumn('email');
    
    // cria crit�rio de sele��o de dados
    $criteria = new TCriteria;
    
    // obt�m a pessoa de c�digo "8"
    $criteria->add(new TFilter('codigo', '=', $_POST['codigo']));
    
    // atribui o crit�rio de sele��o de dados
    $sql->setCriteria($criteria);
    
    // obt�m a conex�o ativa
    $conn = TTransaction::get();
    
    // executa a instru��o SQL
    $result = $conn->query($sql->getInstruction());
    
    if ($result)
    {
        $row = $result->fetch(PDO::FETCH_ASSOC);
        // exibe os dados resultantes
        echo "[ Dados do Cliente Pesquisado ]<br>";
        echo $row['nome'] . ' - '. $row['endereco']. ' - '. $row['email']."<br>\n";
    }
    // fecha a conex�o
    $conn = null;
    
    // fecha a transa��o, aplicando todas opera��es
    TTransaction::close();
}
catch (Exception $e)
{
    // exibe a mensagem de erro
    echo $e->getMessage();
    
    // desfaz opera��es realizadas durante a transa��o
    TTransaction::rollback();
}
}
else
{
?>
<form method="post" action=" ">
    <table>
<tr>
	<td>Informe o C�digo do cliente:</td>
	<td><input type="text" name="codigo" size="5" maxlength="3" /></td>
</tr>
<tr>
<td><input type="submit" value="[ Enviar ]" /></td>
	<td><input type="reset" value="[ Limpar ]" /></td>
</tr>
</table>
<input type="hidden" value="0" name="flag" />
</form>
<?php
}
    
?>
<?php

/**
 * @author Hudson Costa
 * @copyright 2015
 */

//Verifica se o formul�rio j� os dados do formul�rio foram enviados

if (isSet($_POST['flag']))
{
 function __autoload($classe)
{
    if (file_exists("app.ado/{$classe}.class.php"))
    {
        include_once "app.ado/{$classe}.class.php";
    }
}

try
{
    // abre uma transa��o
    TTransaction::open('exemploBD');
    
    // cria uma instru��o de INSERT
    $sql = new TSqlInsert;
    
    // define o nome da entidade
    $sql->setEntity('clientes');
    
    // atribui o valor de cada coluna
    $sql->setRowData('codigo',$_POST['codigo']);
    $sql->setRowData('nome', $_POST['nome']);
    $sql->setRowData('endereco', $_POST['endereco'] );
    $sql->setRowData('email', $_POST['email']);
    
    // obt�m a conex�o ativa
    $conn = TTransaction::get();
    
    // executa a instru��o SQL
    $result = $conn->Query($sql->getInstruction());
    
    // fecha a transa��o, aplicando todas opera��es
    TTransaction::close();
    echo "Cadastro realizado com sucesso!<br>";
    echo "<a href=\"aplicTesteBD.htm\">[ Voltar ao Menu Inicial ]</a>";
}
catch (Exception $e)
{
    // exibe a mensagem de erro
    echo $e->getMessage();
    
    // desfaz opera��es realizadas durante a transa��o
    TTransaction::rollback();
}    
}
else
{
?>
<form method="post" action=" ">
<table>
<tr>
	<td>Codigo:</td>
	<td><input type="text" name="codigo" size="5" maxlength="3" /></td>
</tr>
<tr>
	<td>Nome:</td>
	<td><input type="text" name="nome" size="30" /></td>
</tr>
<tr>
	<td>Endere�o: </td>
	<td><input type="text" name="endereco" size="30"/></td>
</tr>
<tr>
<td>E-mail:</td>
	<td><input type="text" name="email" size="30" /></td>
	
</tr>
<tr>
<td><input type="submit" value="[ Enviar ]" /></td>
	<td><input type="reset" value="[ Limpar ]" /></td>
</tr>
</table>
<input type="hidden" value="0" name="flag" />
</form>
<?php
}
?>
% Autor: Hudson Costa
% Data: 15/03/2018

prog :- ler(Dado),
     calcular(Dado, Result),
     imprimir(Result).

calcular(Dado, Quadr) :- Quadr is Dado * Dado.
ler(Dado) :- write('Digite um valor: '), read(Dado).
imprimir(Result) :- write('O quadrado eh: '), write(Result), nl.
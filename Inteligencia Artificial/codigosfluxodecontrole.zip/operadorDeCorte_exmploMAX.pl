% Autor: Hudson Costa
% Data: 15/03/2018

max(X,Y,M) :- X > Y, M=X.
max(X,Y,M) :- X < Y, M=Y.
max(X,Y,M) :- X=Y, M=X.

max0(X,Y,M) :- X>Y, !, M=X.
max0(X,Y,M) :- X<Y, !, M=Y.
max0(X,Y,M) :- X=Y, !, M=X.

max00(X,Y,M) :- (X>Y,!,M=X; X<Y,!,M=Y; X=Y, !, M=X).

max1(X,Y,X) :- X>Y, !.
max1(X,Y,Y).

max2(X,Y,X) :- X >Y.
max2(X,Y,Y).
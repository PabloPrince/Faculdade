% Autor: Hudson Costa
% Data: 15/03/2018

pai(tare, abraao).
pai(tare, nacor).
pai(aran, lot).

%consulta: pai(X,Y), write((pai(X,Y)), nl, fail.

%consulta2: pai(X,Y), !, fail.
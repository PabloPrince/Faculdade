% Autor: Hudson Costa
% Data: 15/03/2018

max5(X,Y,M) :- (X>Y -> M=X; M=Y).
max6(X,Y,M) :- (X>Y, !, M=X; M=Y).

%outra forma
se(Condition, Then, Else) :- Condition, !, Then.
se(_,_,Else) :- Else.
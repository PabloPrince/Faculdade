% Autor: Hudson Costa
% Data: 15/03/2018

%Maria gosta de todos os animais, menos de cobras.
% gosta(maria, X), animal(X).
% Se X � uma cobra,
%   ent�o n�o � verdade que Maria gosta de X
%   sen�o se X � um animal, ent�o Maria gosta de X.

gosta(maria, X) :-
             cobral(X),
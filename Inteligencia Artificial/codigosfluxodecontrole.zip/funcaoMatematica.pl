% Autor: Hudson Costa
% Data: 15/03/2018

%f(X,0) :- X<5.
%f(X,1) :- X >= 5, X =< 9.
%f(X,2) :- X > 9.

f(X,0) :- X<5, !.
f(X,1) :- X >= 5, X =< 9, !.
f(X,2) :- X > 9.
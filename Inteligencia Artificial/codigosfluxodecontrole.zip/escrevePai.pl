% Autor: Hudson Costa
% Data: 15/03/2018

pai(tare, abraao).
pai(tare, nacor).
pai(aran, lot).

escreve :- pai(X,Y), write(X), write(' eh pai de '), write(Y), nl, fail.

escreve1 :- pai(X,Y), write(X), write(' eh pai de '), write(Y), nl, fail.
escreve1 :- true.
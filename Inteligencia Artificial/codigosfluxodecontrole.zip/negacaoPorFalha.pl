% Autor:
% Data: 15/03/2018
pessoa(X) :- member(X, [jose, ana, maria, pedro, antonia]).
namora(jose, ana).
casal(joao, maria).
casal(pedro, antonia).
casado(X) :- casal(X,_); casal(_,X).
solteiro(X) :- \+ casado(X).
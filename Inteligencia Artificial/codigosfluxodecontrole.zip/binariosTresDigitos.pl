% Autor:  Hudson Costa
% Data: 15/03/2018
d(0).
d(1).
b([A, B, C]) :- d(A), d(B), d(C).

bin :- d(A), d(B), d(C), write([A,B,C]), nl, fail.
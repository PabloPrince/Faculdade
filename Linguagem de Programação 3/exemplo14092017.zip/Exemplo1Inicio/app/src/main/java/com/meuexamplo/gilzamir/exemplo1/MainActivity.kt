package com.meuexamplo.gilzamir.exemplo1
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.EditText
var internalTransition = false
class MainActivity : AppCompatActivity() {
    lateinit var editTextNome:EditText
    lateinit var editTextAltura:EditText
    lateinit var editTextMassa:EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        editTextNome = findViewById<EditText>(R.id.nome)
        editTextMassa = findViewById<EditText>(R.id.massa)
        editTextAltura = findViewById<EditText>(R.id.altura)
        Log.e("TRACKING", "OnCreate")
    }

    override fun onStart() {
        super.onStart()
        if (internalTransition) {
            editTextNome.text.clear()
            internalTransition = false
        }
        Log.e("TRACKING", "OnStart")
    }

    override fun onPause() {
        super.onPause()
        Log.e("TRACKING", "OnPause")
    }

    override fun onStop() {
        super.onStop()
        Log.e("TRACKING", "OnStop")
    }

    override fun onRestart() {
        super.onRestart()
        Log.e("TRACKING", "OnRestart")
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        Log.e("TRACKING", "onWindowFocusChanged")
    }

    override fun onResume() {
        super.onResume()
        Log.e("TRACKING", "OnResume")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.e("TRACKING", "OnDestroy")
    }

    fun calcularIMC(view: View){
        val entradaNome = (findViewById<EditText>(R.id.nome) as EditText).text.toString()

        val entradaAltura = (findViewById<EditText>(R.id.altura) as EditText).text
                .toString().toFloat()

        val entradaMassa = (findViewById<EditText>(R.id.massa) as EditText).text
                .toString().toFloat()

        val pessoa = Pessoa(entradaNome, entradaAltura, entradaMassa)
        pessoas.add(pessoa)
        val intent = Intent(this, MostrarIMC::class.java)
        internalTransition = true
        startActivity(intent)
    }
}

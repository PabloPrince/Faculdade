package com.meuexamplo.gilzamir.exemplo1

import android.app.Activity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView

val DADOS_DE_PESSOA = "DADOS_DE_PESSOA"

val pessoas = mutableListOf<Pessoa>()

/**
 * Created by gilzamir on 28/07/17.
 */
class MostrarIMC : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mostrarimc)
        if (pessoas != null) {
            val listViewPessoas = findViewById<ListView>(R.id.listaPessoas)
            listViewPessoas.adapter = ArrayAdapter<Pessoa>(this, android.R.layout.simple_list_item_1, pessoas)
        }
    }
}

